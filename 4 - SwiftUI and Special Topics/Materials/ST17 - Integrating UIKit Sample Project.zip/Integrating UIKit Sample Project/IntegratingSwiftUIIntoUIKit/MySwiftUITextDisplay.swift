//
//  MySwiftUIView.swift
//  TestingExampleUIKit
//
//  Created by Parker Rushton on 6/5/24.
//

import SwiftUI
import UIKit

struct MySwiftUITextDisplay: View {
    var body: some View {
        ZStack {
            Color.red
            VStack {
                Text("This is my custom SwiftUI Text Display view")
                Text("You can tell its SwiftUI because of the way it is")
            }
            .padding()
        }
        .ignoresSafeArea()
    }
}

#Preview {
    MySwiftUITextDisplay()
}

class MyTextDisplayHostingController: UIHostingController<MySwiftUITextDisplay> {
    // The storyboard uses this subclass for the relevant view

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder, rootView: MySwiftUITextDisplay())
    }
}
