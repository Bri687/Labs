//
//  EmbedSwiftUIInUIKitViewController.swift
//  TestingExampleUIKit
//
//  Created by Parker Rushton on 6/5/24.
//

import UIKit
import SwiftUI

class EmbedSwiftUIInUIKitViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBSegueAction func showMyImageDisplay(_ coder: NSCoder) -> UIViewController? {
        // This segue action shows the SwiftUI View at runtime by returning a freshly initialized UIHostingController below
        return UIHostingController(coder: coder, rootView: MySwiftUIImageDisplay())
    }
}
