//
//  MySwiftUIView.swift
//  TestingExampleUIKit
//
//  Created by Parker Rushton on 6/5/24.
//

import SwiftUI
import UIKit

struct MySwiftUIImageDisplay: View {
    var body: some View {
        ZStack {
            Color.green

            Image(systemName: "rainbow")
                .resizable()
                .scaledToFit()
                .padding()
        }
        .ignoresSafeArea()
    }
}

#Preview {
    MySwiftUIImageDisplay()
}
