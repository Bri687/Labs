//
//  EmbedUIKitInSwiftUIView.swift
//  TestingExampleUIKit
//
//  Created by Jane Madsen on 6/5/24.
//

import SwiftUI

struct EmbedUIKitInSwiftUIView: View {
    @State var text: String = ""
    
    var body: some View {
        ZStack {
            Color.cyan
                .ignoresSafeArea()
            
            MyUIKitTextFieldView(text: $text)
                .background {
                    Color.white
                }
                .frame(maxHeight: 100)
                .padding()
        }
    }
}

struct MyUIKitTextFieldView: UIViewRepresentable {
    @Binding var text: String
    
    func makeUIView(context: Context) -> UITextField {
        // This is where the UITextField gets created.
        let textField = UITextField()
        textField.placeholder = "This is my text field. :)"
        
        // We set the coordinator as the textField's delegate. See below.
        textField.delegate = context.coordinator
        return textField
    }
    
    func updateUIView(_ uiView: UITextField, context: Context) {
        // This function gets called whenever SwiftUI updates the view.
        // Think "What is coming into UIKit from SwiftUI?"
        uiView.text = text
    }
    
    class Coordinator: NSObject, UITextFieldDelegate {
        // The coordinator class is used to manage the interactions between UIKit and SwiftUI.
        // We can set up the coordinator however we want.
        // Here we decided to use the coordinator to handle UITextFieldDelegate methods that get called when the UITextField's text changes.
        
        var parent: MyUIKitTextFieldView
        
        init(parent: MyUIKitTextFieldView) {
            self.parent = parent
        }
        
        func textFieldDidChangeSelection(_ textField: UITextField) {
            // This delegate method is called whenever the text in the UITextField changes.
            // Think "What is going out of UIKit into SwiftUI?"
            parent.text = textField.text ?? ""
        }
    }
    
    func makeCoordinator() -> Coordinator {
        // This gets called before makeUIView, ensuring the coordinator is available when the view is created.
        Coordinator(parent: self)
    }
}

#Preview {
    EmbedUIKitInSwiftUIView()
}
