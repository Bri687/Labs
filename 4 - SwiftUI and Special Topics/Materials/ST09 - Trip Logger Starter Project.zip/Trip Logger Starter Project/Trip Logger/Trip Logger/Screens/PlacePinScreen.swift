//
//  PlacePinScreen.swift
//  Trip Logger
//
//  Created by Jane Madsen on 4/29/25.
//


import SwiftUI
import SwiftData
import MapKit
import PhotosUI

struct PlacePinScreen: View {
    var body: some View {
        VStack {
            MapReader { reader in // Allows conversion of a touch gesture into coordinates
                Map {
                    // TODO: Display the pin the user placed

                }
                .onTapGesture { location in
                    placePin(reader: reader, location: location)
                }
            }
        }
        .navigationTitle("Place First Pin")

    }
    
    func placePin(reader: MapProxy, location: CGPoint) {
        if let coordinate = reader.convert(location, from: .local) {
        
        }
    }
}

#Preview {
    PlacePinScreen()
        .modelContainer(ModelContainer.preview)
}
