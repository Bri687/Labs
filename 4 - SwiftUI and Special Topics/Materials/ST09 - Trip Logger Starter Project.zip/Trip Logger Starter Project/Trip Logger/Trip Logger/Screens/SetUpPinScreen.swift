//
//  SetUpPinScreen.swift
//  Trip Logger
//
//  Created by Jane Madsen on 4/29/25.
//


import SwiftUI
import SwiftData
import MapKit
import PhotosUI

struct SetUpPinScreen: View {
    var body: some View {
        VStack {
            Text("Name your first pin, add photos, and add notes to this stop")
        }
    }
}

#Preview {
    SetUpPinScreen()
}
